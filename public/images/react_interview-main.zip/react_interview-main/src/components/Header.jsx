import React from 'react'

const Header = () => {
  return <header>LIVAD</header>
}

export default Header
